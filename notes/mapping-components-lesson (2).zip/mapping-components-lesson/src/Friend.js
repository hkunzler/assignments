import React from 'react'

const Friend = (props) => {
    return (
        <li>
            {props.name}
        </li>
    )
}

export default Friend